<?php session_start();
if(isset($_SESSION['nom'])){
  $nom =$_SESSION['nom']; 
  $fnc = $_SESSION['fnc'];
}else{
        echo '<script language="Javascript">';
        echo 'document.location.replace("./logout.php")'; // -->
        echo ' </script>';
}
?>

<!doctype html>
<html lang="en">

<head>
  <title>Users</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />

  <!--bootstrap-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

  <!--Font awasome-->
  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
  <div class="wrapper ">
 

 <!-- Administrateur sidebar -->
  <?php
          if($fnc != 'Superviseur' && $fnc != 'Opérateur'){
          ?>

    <div class="sidebar" data-color="green" data-background-color="white">
    <!--Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

    Tip 2: you can also add an image using data-image tag-->
    <div class="logo">
     <a href="page.php" class="simple-text logo-mini">
        <img src="avatar.png">
      </a>
      <h3 href="" class="simple-text logo-normal">
        <?php echo "$nom"; ?>
      <h3>
      <h5 class="text-center"><?php echo "$fnc"; ?></h5>
    </div>
    <div class="sidebar-wrapper ">
      <ul class="nav">
        <li class="nav-item active  ">
          <a class="nav-link" href="#0">
            <i class="material-icons">dashboard</i>
            <p>Dashboard</p>
          </a>
        </li>

        <ul class="list-group mt-5 ">
          <li class="list-group-item">Josco</li>
          <li class="list-group-item">Josco</li>
          <li class="list-group-item">Josco</li>
        <!-- your sidebar here -->
      </ul>
    </div>
  </div>

    <!-- Operateur sidebar --> 
            <?php
          }elseif($fnc!= 'Superviseur'){
          ?>
              
    <div class="sidebar" data-color="orange" data-background-color="white">
      <div class="logo">
        <a href="page.php" class="simple-text logo-mini">
          <img src="avatar.png">
        </a>
        <h3 href="" class="simple-text logo-normal">
          <?php echo "$nom"; ?>
        <h3>
        <h5 class="text-center"><?php echo "$fnc"; ?></h5>
      </div>
      <div class="sidebar-wrapper ">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="#0">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <ul class="list-group mt-5 ">
          <h6 class="text-center" >Enregistrement</h6>
            <li class="list-group-item pl-2"> <a href="acc.php"><i class=" fa fa-plus-circle"></i>Enregistrer un danger</a> </li>
            <li class="list-group-item pl-2"> <a href="lieu.php"><i class=" fa fa-plus-circle"></i>Ajouter un lieu</a> </li>
          </ul>
          <ul class="list-group mt-4 ">
          <h6 class="text-center">Modification/Suppression</h6>
            <li class="list-group-item pl-2"> <a href="register.php"><i class="fas fa-tools"></i>Modifier un danger</a> </li>
          </ul>
          
          <!-- your sidebar here -->
      </div>
    </div>




              <?php
            } else {
                ?> 


<!-- Superviseur sidebar -->


  <div class="sidebar" data-color="green" data-background-color="white">
      <div class="logo">
      <a href="page.php" class="simple-text logo-mini">
          <img src="avatar.png">
        </a>
        <h3 href="" class="simple-text logo-normal">
          <?php echo "$nom"; ?>
        <h3>
        <h5 class="text-center"><?php echo "$fnc"; ?></h5>
      </div>
      <div class="sidebar-wrapper ">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="#0">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <ul class="list-group mt-5 ">
            <li class="list-group-item">Josco</li>
            <li class="list-group-item">Josco</li>
            <li class="list-group-item">Josco</li>
          <!-- your sidebar here -->
        </ul>
      </div>
    </div>





     <?php }?>
  
      <!-- Navbar -->
      <nav class="navbar navbar-light p-0 bg-info mb-0 ">
        <a class="" href="#">
          <img src="danger.png" width="150" height="auto" class="d-inline-block align-top img-fluid" alt="logo" style="margin-left: 250px;">
        </a>

        <ul class="navbar mr-5" style="list-style: none; font-size: 25px;">
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"><i class="fas fa-bell"></i></li>
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"><i class="fas fa-envelope"></i></li>
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"> <a href="logout.php"><i class="fas fa-sign-out-alt"></i></a> </li>
        </ul>

      </nav>
      <!-- End Navbar -->
      <div class="content"style="margin-left: 250px;">
        <div class="container-fluid" >
          <!-- your content here -->

            <?php
                  if($fnc != 'Superviseur' && $fnc != 'Opérateur'){
                  ?>
            <!-- Administrateur -->


          <div class="row ml-4 ">
              


            <!-- Nombres d'inscription -->
            <div class="col mb-4 p-0">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Inscription Utilisateurs</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                      
                      <?php
                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";
                      
                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }

                      $query = "SELECT id FROM utilisateurs";

                      $query_run = mysqli_query($conn, $query);

                      $row = mysqli_num_rows($query_run);

                      echo '<h1> '.$row. '</h1><br>';
                      
                      
                      ?>
                      <h4>Inscris</h4>
                      </div>
                    </div>
                    <div class="col-auto mr-5">
                      <i class="fas fa-users fa-2x text-gray-300" style="font-size: 70px;"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!--  (-->
    

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Dangers enregistrés</div>
                      <div class="row no-gutters align-items-center">
                        <div class="col-auto">
                           
                          <?php
                          $servername = "localhost";
                          $username = "root";
                          $password = "";
                          $dbname = "dangerviewdb";
                          
                          // Create connection
                          $conn = mysqli_connect($servername, $username, $password, $dbname);
                          // Check connection
                          if (!$conn) {
                            die("Connection failed: " . mysqli_connect_error());
                          }

                          $query = "SELECT id FROM dangertable";

                          $query_run = mysqli_query($conn, $query);

                          $row = mysqli_num_rows($query_run);

                          echo '<h1> '.$row. '</h1><br>';
                          
                          
                          ?>
                          
                        </div>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-clipboard-list fa-2x text-gray-300" style="font-size: 70px;"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1 mB-3">Message reçus</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">18</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-comments fa-2x text-gray-300 mt" style="font-size: 70px;"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>


          <div class="row mb-3 ml-5 mr-2">
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Pending Requests</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">18</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-comments fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>


          <!-- Content Row -->

          <div class="row">

            <!-- Area Chart -->
            <div class="col-xl-8 col-lg-7">
              <div class="card shadow ml-5">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Total Inscription</h6>
                  <div class="dropdown no-arrow">
                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                      <div class="dropdown-header">Dropdown Header:</div>
                      <a class="dropdown-item" href="#">Action</a>
                      <a class="dropdown-item" href="#">Another action</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="#">Something else here</a>
                    </div>
                  </div>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                  <div class="chart-area">
                    <canvas id="myAreaChart"></canvas>
                  </div>
                </div>
              </div>
            </div>

          <!-- Content Row -->
          </div class="col-xl-4 ml-5" >


          </div>
    </div>


        <!--Fin administrateur-->


            
            <?php
          }elseif($fnc!= 'Superviseur'){
          ?>
              
            <!-- Opérateur -->

            <div class="col ">
              <div class="jumbotron color1 rounded-0 pt-0 ">
                  <div class="row">
                    <div class="col color2 mt-3 rounded d-flex justify-content-center bg-dark">
                      <h1 style="color: #FFF;">Contenu</h1>
                    </div>
                  </div>
                  <div class="container">
                    <div class="row justify-content-center align-items-center ">
                      <div class="col-6 card card-body mt-4 shadow bg-warning ">
                        <h2 class="mb-4">Ajouter un lieu     <i class="fas fa-map-marker-alt"></i></h2>

        <!-- Formulaire d'enregistrement infos -->

                      <?php

                          if (isset($_POST['savedanger'])) {?>
                            
                          <div class="alert alert-success alert-dismissible fade show" role="alert">
                            Enregistré avec succes !
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>

                      <?php }?>

                      <!-- alerte -->





                      <?php

                            $servername = "localhost";
                            $username = "root";
                            $password = "";
                            $dbname = "dangerviewdb";

                            // Create connection
                            $conn = mysqli_connect($servername, $username, $password, $dbname);
                            // Check connection
                            if (!$conn) {
                            die("Connection failed: " . mysqli_connect_error());
                            }

                            if(isset($_POST['savelieu'])){
                            $nom = $_POST['nom'];
                            $pays = $_POST['pays'];
                            $ville = ($_POST['ville']);
                            $quartier = $_POST['quartier'];
                            $demographie = $_POST['demographie'];
                            $geographie = $_POST['geographie'];

                            $sql = "INSERT INTO lieu (nom, pays, ville, quartier, demographie, geographie)
                            VALUES ('$nom', '$pays', '$ville', '$quartier', '$demographie', '$geographie')";

                            if (mysqli_query($conn, $sql)) {
                            echo "information enregistrée";
                            } else {
                            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
                            }

                            }



                            mysqli_close($conn);

                            ?>

                      <form class="user" action="" method="POST">
                        <div class="form-group">
                          <label class="text-dark" for="formGroupExampleInput">Nom du lieu :</label>
                          <input type="text" name="nom" id="formGroupExampleInput" class="form-control">
                        </div>
                        <div class="form-group">
                          <label class="text-dark" for="exampleFormControlSelect1">Pays :</label>
                          <select class="form-control" name="pays" id="formGroupExampleInput" placeholder=" Entrez votre le pays">
                            <option value="">--- Sélectionner un pays ---</option>
                            <option value="4;AF;AFG;Afghanistan">Afghanistan</option>
                            <option value="710;ZA;ZAF;Afrique du Sud">Afrique du Sud</option>
                            <option value="248;AX;ALA;Aland (Îles)">Aland (Îles)</option>
                            <option value="8;AL;ALB;Albanie">Albanie</option>
                            <option value="12;DZ;DZA;Algérie">Algérie</option>
                            <option value="276;DE;DEU;Allemagne">Allemagne</option>
                            <option value="20;AD;AND;Andorre">Andorre</option>
                            <option value="24;AO;AGO;Angola">Angola</option>
                            <option value="660;AI;AIA;Anguilla">Anguilla</option>
                            <option value="10;AQ;ATA;Antarctique">Antarctique</option>
                            <option value="28;AG;ATG;Antigua-et-Barbuda">Antigua-et-Barbuda</option>
                            <option value="682;SA;SAU;Arabie saoudite">Arabie saoudite</option>
                            <option value="32;AR;ARG;Argentine">Argentine</option>
                            <option value="51;AM;ARM;Arménie">Arménie</option>
                            <option value="533;AW;ABW;Aruba">Aruba</option>
                            <option value="36;AU;AUS;Australie">Australie</option>
                            <option value="40;AT;AUT;Autriche">Autriche</option>
                            <option value="31;AZ;AZE;Azerbaïdjan">Azerbaïdjan</option>
                            <option value="44;BS;BHS;Bahamas">Bahamas</option>
                            <option value="48;BH;BHR;Bahreïn">Bahreïn</option>
                            <option value="50;BD;BGD;Bangladesh">Bangladesh</option>
                            <option value="52;BB;BRB;Barbade">Barbade</option>
                            <option value="56;BE;BEL;Belgique">Belgique</option>
                            <option value="84;BZ;BLZ;Belize">Belize</option>
                            <option value="60;BM;BMU;Bermudes">Bermudes</option>
                            <option value="64;BT;BTN;Bhoutan">Bhoutan</option>
                            <option value="68;BO;BOL;Bolivie (État plurinational de)">Bolivie (État plurinational de)</option>
                            <option value="535;BQ;BES;Bonaire, Saint-Eustache et Saba">Bonaire, Saint-Eustache et Saba</option>
                            <option value="70;BA;BIH;Bosnie-Herzégovine">Bosnie-Herzégovine</option>
                            <option value="72;BW;BWA;Botswana">Botswana</option>
                            <option value="74;BV;BVT;Bouvet (Île)">Bouvet (Île)</option>
                            <option value="96;BN;BRN;Brunéi Darussalam">Brunéi Darussalam</option>
                            <option value="76;BR;BRA;Brésil">Brésil</option>
                            <option value="100;BG;BGR;Bulgarie">Bulgarie</option>
                            <option value="854;BF;BFA;Burkina Faso">Burkina Faso</option>
                            <option value="108;BI;BDI;Burundi">Burundi</option>
                            <option value="112;BY;BLR;Bélarus">Bélarus</option>
                            <option value="204;BJ;BEN;Bénin">Bénin</option>
                            <option value="132;CV;CPV;Cabo Verde">Cabo Verde</option>
                            <option value="116;KH;KHM;Cambodge">Cambodge</option>
                            <option value="120;CM;CMR;Cameroun">Cameroun</option>
                            <option value="124;CA;CAN;Canada">Canada</option>
                            <option value="136;KY;CYM;Caïmans (Îles)">Caïmans (Îles)</option>
                            <option value="152;CL;CHL;Chili">Chili</option>
                            <option value="156;CN;CHN;Chine">Chine</option>
                            <option value="162;CX;CXR;Christmas (Île)">Christmas (Île)</option>
                            <option value="196;CY;CYP;Chypre">Chypre</option>
                            <option value="166;CC;CCK;Cocos (Îles) / Keeling (Îles)">Cocos (Îles) / Keeling (Îles)</option>
                            <option value="170;CO;COL;Colombie">Colombie</option>
                            <option value="174;KM;COM;Comores">Comores</option>
                            <option value="178;CG;COG;Congo">Congo</option>
                            <option value="180;CD;COD;Congo (République démocratique du)">Congo (République démocratique du)</option>
                            <option value="184;CK;COK;Cook (Îles)">Cook (Îles)</option>
                            <option value="410;KR;KOR;Corée (République de)">Corée (République de)</option>
                            <option value="408;KP;PRK;Corée (République populaire démocratique de)">Corée (République populaire démocratique de)</option>
                            <option value="188;CR;CRI;Costa Rica">Costa Rica</option>
                            <option value="191;HR;HRV;Croatie">Croatie</option>
                            <option value="192;CU;CUB;Cuba">Cuba</option>
                            <option value="531;CW;CUW;Curaçao">Curaçao</option>
                            <option value="384;CI;CIV;Côte d'Ivoire">Côte d'Ivoire</option>
                            <option value="208;DK;DNK;Danemark">Danemark</option>
                            <option value="262;DJ;DJI;Djibouti">Djibouti</option>
                            <option value="214;DO;DOM;dominicaine (République)">dominicaine (République)</option>
                            <option value="212;DM;DMA;Dominique">Dominique</option>
                            <option value="818;EG;EGY;Egypte">Egypte</option>
                            <option value="222;SV;SLV;El Salvador">El Salvador</option>
                            <option value="784;AE;ARE;Emirats arabes unis">Emirats arabes unis</option>
                            <option value="218;EC;ECU;Equateur">Equateur</option>
                            <option value="232;ER;ERI;Erythrée">Erythrée</option>
                            <option value="724;ES;ESP;Espagne">Espagne</option>
                            <option value="233;EE;EST;Estonie">Estonie</option>
                            <option value="840;US;USA;Etats-Unis d'Amérique">Etats-Unis d'Amérique</option>
                            <option value="231;ET;ETH;Ethiopie">Ethiopie</option>
                            <option value="238;FK;FLK;Falkland (Îles) / Malouines (Îles)">Falkland (Îles) / Malouines (Îles)</option>
                            <option value="242;FJ;FJI;Fidji">Fidji</option>
                            <option value="246;FI;FIN;Finlande">Finlande</option>
                            <option value="250;FR;FRA;France">France</option>
                            <option value="234;FO;FRO;Féroé (Îles)">Féroé (Îles)</option>
                            <option value="266;GA;GAB;Gabon">Gabon</option>
                            <option value="270;GM;GMB;Gambie">Gambie</option>
                            <option value="288;GH;GHA;Ghana">Ghana</option>
                            <option value="292;GI;GIB;Gibraltar">Gibraltar</option>
                            <option value="308;GD;GRD;Grenade">Grenade</option>
                            <option value="304;GL;GRL;Groenland">Groenland</option>
                            <option value="300;GR;GRC;Grèce">Grèce</option>
                            <option value="312;GP;GLP;Guadeloupe">Guadeloupe</option>
                            <option value="316;GU;GUM;Guam">Guam</option>
                            <option value="320;GT;GTM;Guatemala">Guatemala</option>
                            <option value="831;GG;GGY;Guernesey">Guernesey</option>
                            <option value="324;GN;GIN;Guinée">Guinée</option>
                            <option value="226;GQ;GNQ;Guinée équatoriale">Guinée équatoriale</option>
                            <option value="624;GW;GNB;Guinée-Bissau">Guinée-Bissau</option>
                            <option value="328;GY;GUY;Guyana">Guyana</option>
                            <option value="254;GF;GUF;Guyane française">Guyane française</option>
                            <option value="268;GE;GEO;Géorgie">Géorgie</option>
                            <option value="239;GS;SGS;Géorgie du Sud-et-les Îles Sandwich du Sud">Géorgie du Sud-et-les Îles Sandwich du Sud</option>
                            <option value="332;HT;HTI;Haïti">Haïti</option>
                            <option value="334;HM;HMD;Heard-et-MacDonald (Île)">Heard-et-MacDonald (Île)</option>
                            <option value="340;HN;HND;Honduras">Honduras</option>
                            <option value="344;HK;HKG;Hong Kong">Hong Kong</option>
                            <option value="348;HU;HUN;Hongrie">Hongrie</option>
                            <option value="833;IM;IMN;Ile de Man">Ile de Man</option>
                            <option value="581;UM;UMI;Iles mineures éloignées des États-Unis">Iles mineures éloignées des États-Unis</option>
                            <option value="356;IN;IND;Inde">Inde</option>
                            <option value="86;IO;IOT;Indien (Territoire britannique de océan)">Indien (Territoire britannique de océan)</option>
                            <option value="360;ID;IDN;Indonésie">Indonésie</option>
                            <option value="364;IR;IRN;Iran (République Islamique d')">Iran (République Islamique d')</option>
                            <option value="368;IQ;IRQ;Iraq">Iraq</option>
                            <option value="372;IE;IRL;Irlande">Irlande</option>
                            <option value="352;IS;ISL;Islande">Islande</option>
                            <option value="376;IL;ISR;Israël">Israël</option>
                            <option value="380;IT;ITA;Italie">Italie</option>
                            <option value="388;JM;JAM;Jamaïque">Jamaïque</option>
                            <option value="392;JP;JPN;Japon">Japon</option>
                            <option value="832;JE;JEY;Jersey">Jersey</option>
                            <option value="400;JO;JOR;Jordanie">Jordanie</option>
                            <option value="398;KZ;KAZ;Kazakhstan">Kazakhstan</option>
                            <option value="404;KE;KEN;Kenya">Kenya</option>
                            <option value="417;KG;KGZ;Kirghizistan">Kirghizistan</option>
                            <option value="296;KI;KIR;Kiribati">Kiribati</option>
                            <option value="414;KW;KWT;Koweït">Koweït</option>
                            <option value="418;LA;LAO;Lao, République démocratique populaire">Lao, République démocratique populaire</option>
                            <option value="426;LS;LSO;Lesotho">Lesotho</option>
                            <option value="428;LV;LVA;Lettonie">Lettonie</option>
                            <option value="422;LB;LBN;Liban">Liban</option>
                            <option value="434;LY;LBY;Libye">Libye</option>
                            <option value="430;LR;LBR;Libéria">Libéria</option>
                            <option value="438;LI;LIE;Liechtenstein">Liechtenstein</option>
                            <option value="440;LT;LTU;Lituanie">Lituanie</option>
                            <option value="442;LU;LUX;Luxembourg">Luxembourg</option>
                            <option value="446;MO;MAC;Macao">Macao</option>
                            <option value="807;MK;MKD;Macédoine (ex-République yougoslave de)">Macédoine (ex-République yougoslave de)</option>
                            <option value="450;MG;MDG;Madagascar">Madagascar</option>
                            <option value="458;MY;MYS;Malaisie">Malaisie</option>
                            <option value="454;MW;MWI;Malawi">Malawi</option>
                            <option value="462;MV;MDV;Maldives">Maldives</option>
                            <option value="466;ML;MLI;Mali">Mali</option>
                            <option value="470;MT;MLT;Malte">Malte</option>
                            <option value="580;MP;MNP;Mariannes du Nord (Îles)">Mariannes du Nord (Îles)</option>
                            <option value="504;MA;MAR;Maroc">Maroc</option>
                            <option value="584;MH;MHL;Marshall (Îles)">Marshall (Îles)</option>
                            <option value="474;MQ;MTQ;Martinique">Martinique</option>
                            <option value="480;MU;MUS;Maurice">Maurice</option>
                            <option value="478;MR;MRT;Mauritanie">Mauritanie</option>
                            <option value="175;YT;MYT;Mayotte">Mayotte</option>
                            <option value="484;MX;MEX;Mexique">Mexique</option>
                            <option value="583;FM;FSM;Micronésie (États fédérés de)">Micronésie (États fédérés de)</option>
                            <option value="498;MD;MDA;Moldova (République de)">Moldova (République de)</option>
                            <option value="492;MC;MCO;Monaco">Monaco</option>
                            <option value="496;MN;MNG;Mongolie">Mongolie</option>
                            <option value="500;MS;MSR;Montserrat">Montserrat</option>
                            <option value="499;ME;MNE;Monténégro">Monténégro</option>
                            <option value="508;MZ;MOZ;Mozambique">Mozambique</option>
                            <option value="104;MM;MMR;Myanmar">Myanmar</option>
                            <option value="516;NA;NAM;Namibie">Namibie</option>
                            <option value="520;NR;NRU;Nauru">Nauru</option>
                            <option value="558;NI;NIC;Nicaragua">Nicaragua</option>
                            <option value="562;NE;NER;Niger">Niger</option>
                            <option value="566;NG;NGA;Nigéria">Nigéria</option>
                            <option value="570;NU;NIU;Niue">Niue</option>
                            <option value="574;NF;NFK;Norfolk (Île)">Norfolk (Île)</option>
                            <option value="578;NO;NOR;Norvège">Norvège</option>
                            <option value="540;NC;NCL;Nouvelle-Calédonie">Nouvelle-Calédonie</option>
                            <option value="554;NZ;NZL;Nouvelle-Zélande">Nouvelle-Zélande</option>
                            <option value="524;NP;NPL;Népal">Népal</option>
                            <option value="512;OM;OMN;Oman">Oman</option>
                            <option value="800;UG;UGA;Ouganda">Ouganda</option>
                            <option value="860;UZ;UZB;Ouzbékistan">Ouzbékistan</option>
                            <option value="586;PK;PAK;Pakistan">Pakistan</option>
                            <option value="585;PW;PLW;Palaos">Palaos</option>
                            <option value="275;PS;PSE;Palestine, État de">Palestine, État de</option>
                            <option value="591;PA;PAN;Panama">Panama</option>
                            <option value="598;PG;PNG;Papouasie-Nouvelle-Guinée">Papouasie-Nouvelle-Guinée</option>
                            <option value="600;PY;PRY;Paraguay">Paraguay</option>
                            <option value="528;NL;NLD;Pays-Bas">Pays-Bas</option>
                            <option value="608;PH;PHL;Philippines">Philippines</option>
                            <option value="612;PN;PCN;Pitcairn">Pitcairn</option>
                            <option value="616;PL;POL;Pologne">Pologne</option>
                            <option value="258;PF;PYF;Polynésie française">Polynésie française</option>
                            <option value="630;PR;PRI;Porto Rico">Porto Rico</option>
                            <option value="620;PT;PRT;Portugal">Portugal</option>
                            <option value="604;PE;PER;Pérou">Pérou</option>
                            <option value="634;QA;QAT;Qatar">Qatar</option>
                            <option value="642;RO;ROU;Roumanie">Roumanie</option>
                            <option value="826;GB;GBR;Royaume-Uni de Grande-Bretagne et d'Irlande du Nord">Royaume-Uni de Grande-Bretagne et d'Irlande du Nord</option>
                            <option value="643;RU;RUS;Russie (Fédération de)">Russie (Fédération de)</option>
                            <option value="646;RW;RWA;Rwanda">Rwanda</option>
                            <option value="760;SY;SYR;République arabe syrienne">République arabe syrienne</option>
                            <option value="140;CF;CAF;République centrafricaine">République centrafricaine</option>
                            <option value="638;RE;REU;Réunion">Réunion</option>
                            <option value="732;EH;ESH;Sahara occidental">Sahara occidental</option>
                            <option value="652;BL;BLM;Saint-Barthélemy">Saint-Barthélemy</option>
                            <option value="659;KN;KNA;Saint-Kitts-et-Nevis">Saint-Kitts-et-Nevis</option>
                            <option value="674;SM;SMR;Saint-Marin">Saint-Marin</option>
                            <option value="663;MF;MAF;Saint-Martin (partie française)">Saint-Martin (partie française)</option>
                            <option value="534;SX;SXM;Saint-Martin (partie néerlandaise)">Saint-Martin (partie néerlandaise)</option>
                            <option value="666;PM;SPM;Saint-Pierre-et-Miquelon">Saint-Pierre-et-Miquelon</option>
                            <option value="336;VA;VAT;Saint-Siège">Saint-Siège</option>
                            <option value="670;VC;VCT;Saint-Vincent-et-Grenadines">Saint-Vincent-et-Grenadines</option>
                            <option value="654;SH;SHN;Sainte-Hélène, Ascension et Tristan da Cunha">Sainte-Hélène, Ascension et Tristan da Cunha</option>
                            <option value="662;LC;LCA;Sainte-Lucie">Sainte-Lucie</option>
                            <option value="90;SB;SLB;Salomon (Îles)">Salomon (Îles)</option>
                            <option value="882;WS;WSM;Samoa">Samoa</option>
                            <option value="16;AS;ASM;Samoa américaines">Samoa américaines</option>
                            <option value="678;ST;STP;Sao Tomé-et-Principe">Sao Tomé-et-Principe</option>
                            <option value="688;RS;SRB;Serbie">Serbie</option>
                            <option value="690;SC;SYC;Seychelles">Seychelles</option>
                            <option value="694;SL;SLE;Sierra Leone">Sierra Leone</option>
                            <option value="702;SG;SGP;Singapour">Singapour</option>
                            <option value="703;SK;SVK;Slovaquie">Slovaquie</option>
                            <option value="705;SI;SVN;Slovénie">Slovénie</option>
                            <option value="706;SO;SOM;Somalie">Somalie</option>
                            <option value="729;SD;SDN;Soudan">Soudan</option>
                            <option value="728;SS;SSD;Soudan du Sud">Soudan du Sud</option>
                            <option value="144;LK;LKA;Sri Lanka">Sri Lanka</option>
                            <option value="756;CH;CHE;Suisse">Suisse</option>
                            <option value="740;SR;SUR;Suriname">Suriname</option>
                            <option value="752;SE;SWE;Suède">Suède</option>
                            <option value="744;SJ;SJM;Svalbard et Île Jan Mayen">Svalbard et Île Jan Mayen</option>
                            <option value="748;SZ;SWZ;Swaziland">Swaziland</option>
                            <option value="686;SN;SEN;Sénégal">Sénégal</option>
                            <option value="762;TJ;TJK;Tadjikistan">Tadjikistan</option>
                            <option value="834;TZ;TZA;Tanzanie, République-Unie de">Tanzanie, République-Unie de</option>
                            <option value="158;TW;TWN;Taïwan (Province de Chine)">Taïwan (Province de Chine)</option>
                            <option value="148;TD;TCD;Tchad">Tchad</option>
                            <option value="203;CZ;CZE;Tchéquie">Tchéquie</option>
                            <option value="260;TF;ATF;Terres austrafrançaises">Terres austrafrançaises</option>
                            <option value="764;TH;THA;Thaïlande">Thaïlande</option>
                            <option value="626;TL;TLS;Timor-Leste">Timor-Leste</option>
                            <option value="768;TG;TGO;Togo">Togo</option>
                            <option value="772;TK;TKL;Tokelau">Tokelau</option>
                            <option value="776;TO;TON;Tonga">Tonga</option>
                            <option value="780;TT;TTO;Trinité-et-Tobago">Trinité-et-Tobago</option>
                            <option value="788;TN;TUN;Tunisie">Tunisie</option>
                            <option value="795;TM;TKM;Turkménistan">Turkménistan</option>
                            <option value="796;TC;TCA;Turks-et-Caïcos (Îles)">Turks-et-Caïcos (Îles)</option>
                            <option value="792;TR;TUR;Turquie">Turquie</option>
                            <option value="798;TV;TUV;Tuvalu">Tuvalu</option>
                            <option value="804;UA;UKR;Ukraine">Ukraine</option>
                            <option value="858;UY;URY;Uruguay">Uruguay</option>
                            <option value="548;VU;VUT;Vanuatu">Vanuatu</option>
                            <option value="862;VE;VEN;Venezuela (République bolivarienne du)">Venezuela (République bolivarienne du)</option>
                            <option value="92;VG;VGB;Vierges britanniques (Îles)">Vierges britanniques (Îles)</option>
                            <option value="850;VI;VIR;Vierges des États-Unis (Îles)">Vierges des États-Unis (Îles)</option>
                            <option value="704;VN;VNM;Viet Nam">Viet Nam</option>
                            <option value="876;WF;WLF;Wallis-et-Futuna ">Wallis-et-Futuna </option>
                            <option value="887;YE;YEM;Yémen">Yémen</option>
                            <option value="894;ZM;ZMB;Zambie">Zambie</option>
                            <option value="716;ZW;ZWE;Zimbabwe">Zimbabwe</option>
                        </select>
                        </div>
                        <div class="form-group">
                          <label class="text-dark" for="exampleFormControlSelect2">Ville :</label>
                          <input class="form-control" type="text" name="ville" placeholder=" Entrez la ville">
                        </div>
                        <div class="form-group">
                          <label class="text-dark" for="formGroupExampleInput2">QuartIer :</label>
                          <input type="text" class="form-control" id="formGroupExampleInput2" name="quartier" placeholder="Ajouter un quartier">
                        </div>
                        <div class="form-group">
                          <label class="text-dark" for="formGroupExampleInput2">Démographie</label>
                          <input type="text" class="form-control" id="formGroupExampleInput2" name="demographie" placeholder="Ajouter une demographie">
                        </div>
                        <div class="form-group">
                          <label class="text-dark" >Géographie:</label>
                          <input rows="2" class="form-control" name="geographie" placeholder="Coordonnée gérographiques"></input>
                        </div>
                        <input type="submit" name="savelieu" class="btn btn-success mt-3" value="Enregistrer">
                      </form> 
            <!-- fin de formulaire  --> 
                      </div>
                  </div>  
                </div>
              </div>
          </div>




            <?php
          } else {
              ?> 




<div class="row ml-4 ">
              


              <!-- Nombres d'inscription -->
              <div class="col mb-4 p-0">
                <div class="card border-left-primary shadow h-100 py-2">
                  <div class="card-body">
                    <div class="row no-gutters align-items-center">
                      <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Inscription Utilisateurs</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                        <?php
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "dangerviewdb";
                        
                        // Create connection
                        $conn = mysqli_connect($servername, $username, $password, $dbname);
                        // Check connection
                        if (!$conn) {
                          die("Connection failed: " . mysqli_connect_error());
                        }
  
                        $query = "SELECT id FROM utilisateurs";
  
                        $query_run = mysqli_query($conn, $query);
  
                        $row = mysqli_num_rows($query_run);
  
                        echo '<h1> '.$row. '</h1><br>';
                        
                        
                        ?>
                        <h4>Inscris</h4>
                        </div>
                      </div>
                      <div class="col-auto mr-5">
                        <i class="fas fa-users fa-2x text-gray-300" style="font-size: 70px;"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
  
              <!--  (-->
      
  
              <!-- Earnings (Monthly) Card Example -->
              <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-info shadow h-100 py-2">
                  <div class="card-body">
                    <div class="row no-gutters align-items-center">
                      <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Dangers enregistrés</div>
                        <div class="row no-gutters align-items-center">
                          <div class="col-auto">
                             
                            <?php
                            $servername = "localhost";
                            $username = "root";
                            $password = "";
                            $dbname = "dangerviewdb";
                            
                            // Create connection
                            $conn = mysqli_connect($servername, $username, $password, $dbname);
                            // Check connection
                            if (!$conn) {
                              die("Connection failed: " . mysqli_connect_error());
                            }
  
                            $query = "SELECT id FROM dangertable";
  
                            $query_run = mysqli_query($conn, $query);
  
                            $row = mysqli_num_rows($query_run);
  
                            echo '<h1> '.$row. '</h1><br>';
                            
                            
                            ?>
                            
                          </div>
                        </div>
                      </div>
                      <div class="col-auto">
                        <i class="fas fa-clipboard-list fa-2x text-gray-300" style="font-size: 70px;"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
  
              <!-- Pending Requests Card Example -->
              <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-warning shadow h-100 py-2">
                  <div class="card-body">
                    <div class="row no-gutters align-items-center">
                      <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1 mB-3">Message reçus</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">18</div>
                      </div>
                      <div class="col-auto">
                        <i class="fas fa-comments fa-2x text-gray-300 mt" style="font-size: 70px;"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            


         <?php }?>




            </div>
          </div>
          <footer class="footer">
            <div class="container-fluid">
              <nav class="float-left" style="margin-left:250px;">
                <ul>
                  <li>
                    <a href="">
                       DANGER VIEW ENGINE
                    </a>
                  </li>
                </ul>
              </nav>
              <div class="copyright float-right" >
                Copright
                &copy;
                <script>
                  document.write(new Date().getFullYear())
                </script>, 
              </div>
              <!-- your footer here -->
            </div>
          </footer>
        </div>
      </div>

      <?php


      ?>

      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

    </body>

</html>
























