<?php



$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dangerviewdb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

 // mis à jour des modification 

 if(isset($_POST['update']))
 {
    $id = $_POST['id_edit']; 
    $type = $_POST['type_edit'];
    $victime = $_POST ['victime_edit'];
    $bourreau = $_POST ['bourreau_edit'];
    $lieu = $_POST ['lieu_edit'];
    $source = $_POST ['source_edit'];
    $description = $_POST ['description_edit'];


    $query = "UPDATE dangertable SET  type='$type', victime='$victime', bourreau='$bourreau', lieu='$lieu', source='$source', description='$description' WHERE id='$id' "; 
    
    $query_run =mysqli_query($conn, $query);

    if($query_run){

        header('Location: register.php');

    }
     
 }
 

 // suppresssion 

 if(isset($_POST['delete_btn']))
 {
    $id = $_POST['delete_id'];

    $query = "DELETE FROM `dangertable` WHERE id='$id' ";

    $query_run = mysqli_query($conn, $query);

    if(isset($query_run))
    {
       
        header('Location: register.php');
    }

 } else
 {
    header('Location: register.php');

    
 }







 if(isset($_POST['delete_btn'])){
   $suppinfo = $_POST['suppinfo'];
   
   $sql = "INSERT INTO activites (suppinfo)
   VALUES ('$suppinfo)";
   
   if (mysqli_query($conn, $sql)) {
     echo "Un utilisateur a été enregistré";
   } else {
     echo "Error: " . $sql . "<br>" . mysqli_error($conn);
   }
   
   }else{
     echo "saisir les informations de l'utilisateur";
   }
   
   mysqli_close($conn);








   $servername = "localhost";
   $username = "root";
   $password = "";
   $dbname = "dangerviewdb";

   // Create connection
   $conn = mysqli_connect($servername, $username, $password, $dbname);
   // Check connection
   if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
   }

   if(isset($_POST['sendmessage'])){
   $contenu = $_POST['contenu'];


   $sql = "INSERT INTO messages (contenu)
   VALUES ('$contenu')";

   if (mysqli_query($conn, $sql)) {
     echo "information enregistrée";
   } else {
     echo "Error: " . $sql . "<br>" . mysqli_error($conn);
   }

   }




   mysqli_close($conn);




?>