<?php session_start();
if(isset($_SESSION['nom'])){
  $nom =$_SESSION['nom']; 
  $fnc = $_SESSION['fnc'];
}else{
        echo '<script language="Javascript">';
        echo 'document.location.replace("./logout.php")'; // -->
        echo ' </script>';
}
?>

<!doctype html>
<html lang="en">

<head>
  <title>Users</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />

  <!--bootstrap-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

  <!--Font awasome-->
  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
  <div class="wrapper ">
 

 <!-- Administrateur sidebar -->
  <?php
          if($fnc != 'Superviseur' && $fnc != 'Opérateur'){
          ?>

    <div class="sidebar" data-color="green" data-background-color="white">
    <!--Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

    Tip 2: you can also add an image using data-image tag-->
    <div class="logo">
    <a href="page.php" class="simple-text logo-mini">
        <img src="avatar.png">
      </a>
      <h3 href="" class="simple-text logo-normal">
        <?php echo "$nom"; ?>
      <h3>
      <h5 class="text-center"><?php echo "$fnc"; ?></h5>
    </div>
    <div class="sidebar-wrapper ">
      <ul class="nav">
        <li class="nav-item active  ">
          <a class="nav-link" href="#0">
            <i class="material-icons">dashboard</i>
            <p>Dashboard</p>
          </a>
        </li>

        <ul class="list-group mt-5 ">
          <li class="list-group-item">Josco</li>
          <li class="list-group-item">Josco</li>
          <li class="list-group-item">Josco</li>
        <!-- your sidebar here -->
      </ul>
    </div>
  </div>

    <!-- Operateur sidebar --> 
            <?php
          }elseif($fnc!= 'Superviseur'){
          ?>
              
    <div class="sidebar" data-color="orange" data-background-color="white">
      <div class="logo">
      <a href="page.php" class="simple-text logo-mini">
          <img src="avatar.png">
        </a>
        <h3 href="" class="simple-text logo-normal">
          <?php echo "$nom"; ?>
        <h3>
        <h5 class="text-center"><?php echo "$fnc"; ?></h5>
      </div>
      <div class="sidebar-wrapper ">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="#0">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <ul class="list-group mt-5 ">
            <h6 class="text-center" >Enregistrement</h6>
            <li class="list-group-item pl-2"> <a href="page.php"><i class=" fa fa-plus-circle"></i>Enregistrer un danger</a> </li>
            <li class="list-group-item pl-2"> <a href="lieu.php"><i class=" fa fa-plus-circle"></i>Ajouter un lieu</a> </li>
          </ul>
          <ul class="list-group mt-4 ">
            <h6 class="text-center">Modification/Suppression</h6>
            <li class="list-group-item pl-2"> <a href="register.php"><i class="fas fa-tools"></i>Modifier un danger</a> </li>
          </ul>
          <!-- your sidebar here -->
          </ul>
        </ul>
      </div>
    </div>




              <?php
            } else {
                ?> 


<!-- Superviseur sidebar -->


  <div class="sidebar" data-color="green" data-background-color="white">
      <div class="logo">
      <a href="page.php" class="simple-text logo-mini">
          <img src="avatar.png">
        </a>
        <h3 href="" class="simple-text logo-normal">
          <?php echo "$nom"; ?>
        <h3>
        <h5 class="text-center"><?php echo "$fnc"; ?></h5>
      </div>
      <div class="sidebar-wrapper ">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="#0">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <ul class="list-group mt-5 ">
            <li class="list-group-item">Josco</li>
            <li class="list-group-item">Josco</li>
            <li class="list-group-item">Josco</li>
          <!-- your sidebar here -->
        </ul>
      </div>
    </div>





     <?php }?>
  
      <!-- Navbar -->
      <nav class="navbar navbar-light p-0 bg-info mb-0 ">
        <a class="" href="#">
          <img src="danger.png" width="150" height="auto" class="d-inline-block align-top img-fluid" alt="logo" style="margin-left: 250px;">
        </a>

        <ul class="navbar mr-5" style="list-style: none; font-size: 25px;">
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"><i class="fas fa-bell"></i></li>
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"><i class="fas fa-envelope"></i></li>
          <li class="nav-item mx-2 mx-sm-4 mx-md-5"> <a href="logout.php"><i class="fas fa-sign-out-alt"></i></a> </li>
        </ul>

      </nav>
      <!-- End Navbar -->
      <div class="content" style="margin-left: 250px;">
        <div class="container-fluid">
          <!-- your content here -->

            <?php

                  if($fnc != 'Superviseur' && $fnc != 'Opérateur'){
                  ?>

                  <!-- ADMINISTRATEUR -->

                  <p>Administrateur</p>
                    
                    <?php
                  }elseif($fnc!= '7uperviseur'){
                  ?>
                      
                    <!-- OPERATEUR -->

                <div class="container">
                  <div class="col color2 mt-3 mb-5 rounded d-flex justify-content-center bg-dark">
                    <h1 style="color: #FFF;">Contenu</h1>
                  </div>

                        <!-- alerte -->
                  <div class="table-responsive" >
                    <h2 class="text-center">Dangers enregistrés</h2> 


                    
                    <table class="table rounded table-dark">
                      <thead>
                        <tr>
                          <th >Danger</th>
                          <th >Victime</th>
                          <th >Bourreau</th>
                          <th >Lieu</th>
                          <th >Source</th>
                          <th >Description</th>
                          <th >Date</th>
                          <th colspan="2" >Action</th>
                        </tr>
                      </thead>
                      <tbody>
                    <?php

                      $servername = "localhost";
                      $username = "root";
                      $password = "";
                      $dbname = "dangerviewdb";

                      // Create connection
                      $conn = mysqli_connect($servername, $username, $password, $dbname);
                      // Check connection
                      if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }



                    $query = "SELECT * FROM dangertable";
                    $result_danger = mysqli_query($conn, $query);

                    while($row = mysqli_fetch_array($result_danger)) { ?>
                            <tr>
                              <td> <?php echo $row['type'] ?> </td>
                              <td> <?php echo $row['victime'] ?> </td>
                              <td> <?php echo $row['bourreau'] ?> </td>
                              <td> <?php echo $row['lieu'] ?> </td>
                              <td> <?php echo $row['source'] ?> </td>
                              <td> <?php echo $row['description'] ?> </td>
                              <td> <?php echo $row['date'] ?> </td>
                              <td>

                                <form action="register-edit.php" method="POST">
                                  <input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">
                                  <button type="submit" class="btn btn-warning" name="edit_btn"><i class="fa fa-edit"></i></button>
                                </form>
                                  
                              </td>
                              <td>
                              <form action="code.php" method="POST">
                                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                                  <button type="submit" class="btn btn-danger" name="delete_btn"><i class="fa fa-trash"></i></button>
                                </form>
                              </td>
                            </tr>

                    <?php } ?>


                      </tbody>
                    </table>                         
                  </div>
                    
             </div>


                <?php
              } else {
                  ?> 
                <!-- SUPERVISEUR -->



                      <p>Superviseur</p>




             <?php }?>




            </div>
          </div>
          <footer class="footer">
            <div class="container-fluid">
              <nav class="float-left" style="margin-left:250px;">
                <ul>
                  <li>
                    <a href="">
                       DANGER VIEW ENGINE
                    </a>
                  </li>
                </ul>
              </nav>
              <div class="copyright float-right" >
                Copright
                &copy;
                <script>
                  document.write(new Date().getFullYear())
                </script>, 
              </div>
              <!-- your footer here -->
            </div>
          </footer>
        </div>
      </div>

      <?php


      ?>

      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

    </body>

</html>





<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dangerviewdb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

if(isset($_POST['savedanger'])){
$type = $_POST['type'];
$victime = $_POST['victime'];
$bourreau = ($_POST['bourreau']);
$lieu = $_POST['lieu'];
$source = $_POST['source'];
$description = $_POST['description'];

$sql = "INSERT INTO dangertable (type, victime, bourreau, lieu, source, description)
VALUES ('$type', '$victime', '$bourreau', '$lieu', '$source', '$description')";

if (mysqli_query($conn, $sql)) {
  echo "information enregistrée";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

}


$query = "SELECT * FROM dangertype";

$result1 = mysqli_query($conn, $query);



mysqli_close($conn);

?>


















